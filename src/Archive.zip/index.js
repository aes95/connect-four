import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import './index.css';

class Item extends React.Component{
    render(){
        const col = this.props.col
        const row = this.props.row
        return(
            <div data-row={row} 
                data-col={col} 
                className="item" 
                onClick={this.props.click}>
                    <div className="circle" value={this.props.board[col][row]}> </div>
            </div>
        )
    }
}

class Board extends React.Component{
    constructor(props){
        super(props);
        this.handleClick = this.handleClick.bind(this)
        this.state = {
            //7 col and 6 rows
            board: Array(7).fill(Array(6).fill(null)), //allows easier access to columns
            yellowNext: true,
        };
    }

    handleClick(i){
        const box = i.target.closest('.item');
        const col = box.dataset.col;
        const board = this.state.board.slice();
        const next_row = board[col].filter((i) => i != null).length
        console.log(board[col])
        board[col][next_row] = this.state.yellowNext ? 'Y' : 'R';
        console.log(board)
        this.setState({board:board, yellowNext: !this.state.yellowNext})

    }

    render(){
        const cols = [0,1,2,3,4,5]
        const rows= [0,1,2,3,4,5,6]
        const items = cols.map((r) => rows.map((c) => 
            <Item row={r} col={c} 
                    color = {this.state.board[c][r]}
                    key={c.toString()+r.toString()} 
                    board = {this.state.board}
                    click={this.handleClick}/>

            ))
        return (
        <div className="container">
            {items}
        </div>
        )
    }
}

// Render:
class App extends React.Component {
    render(){
        return <Board/>
    }
}

ReactDOM.render(<App />, document.getElementById('root'));

//Game logic:
